class Memo < ApplicationRecord
    belongs_to :category
end
